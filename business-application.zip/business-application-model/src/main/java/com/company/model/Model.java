package com.company.model;


public class Model {


}